const express = require("express");
const bcrypt = require("bcrypt");
const jsonwebtoken = require("jsonwebtoken");

const router = express.Router();

const ClientModel = require("./models/Clients");
const PatriesModel = require("./models/Pastries");
const auth = require("./middlewares/auth");

router.post("/login", postLogin);
router.post("/addClient", postAddClient);
router.post("/play", auth, getResult);
router.get("/stock", checkStock);

function postLogin(req, res) {
  console.log(req.body.email, req.body.password);
  ClientModel.findOne({ email: req.body.email })
    .lean()
    .then((user) => {
      if (!user) return res.status(404).send({ error: "User not found!" });

      bcrypt.compare(req.body.password, user.password).then((isValid) => {
        if (isValid) {
          // Générer le token utilisateur
          const token = jsonwebtoken.sign(user, process.env.APP_TOKEN_SECRET);

          // Envoi du token au client
          return res
            .status(200)
            .send({ success: "Login success!", token, user });
        } else {
          return res.send(403, { error: "Authentication failed!" });
        }
      });
    });
}

function postAddClient(req, res) {
  const newUser = { ...req.body };

  bcrypt
    .hash(req.body.password, 10)
    .then((passwordHashed) => {
      newUser.password = passwordHashed;
      return newUser;
    })
    .then((newUser) => ClientModel.create(newUser))
    .then(() => {
      res.send({ success: "Collaborateur ajouté!" });
    });
}

function getResult(req, res) {
  console.log(req.body);
  const data = req.body.numbers;
  const userId = req.body.userId;
  let tri = new Promise((resolve, reject) => {
    console.log(data.length);
    let resultone = 0;
    let resulttwo = 0;
    let resultthree = 0;
    let resultfour = 0;
    let resultfive = 0;
    let resultsix = 0;
    for (let i = 0; i < data.length; i++) {
      if (data[i] === 1) {
        resultone++;
      } else if (data[i] === 2) {
        resulttwo++;
      } else if (data[i] === 3) {
        resultthree++;
      } else if (data[i] === 4) {
        resultfour++;
      } else if (data[i] === 5) {
        resultfive++;
      } else if (data[i] === 6) {
        resultsix++;
      }
    }
    resolve({
      resultone: resultone,
      resulttwo: resulttwo,
      resultthree: resultthree,
      resultfour: resultfour,
      resultfive: resultfive,
      resultsix: resultsix,
    });
  });

  tri.then(
    ({
      resultone,
      resulttwo,
      resultthree,
      resultfour,
      resultfive,
      resultsix,
    }) => {
      var order = Math.floor(Math.random() * (8 - 1 + 1) + 1);
      var order2 = Math.floor(Math.random() * (8 - 1 + 1) + 1);
      var order3 = Math.floor(Math.random() * (8 - 1 + 1) + 1);
      if (
        resultone === 5 ||
        resulttwo === 5 ||
        resultthree === 5 ||
        resultfour === 5 ||
        resultfive === 5 ||
        resultsix === 5
      ) {
        delete3Item(order, order2, order3, res);
        played(userId);
      } else if (
        resultone === 4 ||
        resulttwo === 4 ||
        resultthree === 4 ||
        resultfour === 4 ||
        resultfive === 4 ||
        resultsix === 4
      ) {
        delete2Item(order, order2, res);
        played(userId);
      } else if (
        (resultone === 2 && resulttwo === 2) ||
        (resultone === 2 && resultthree === 2) ||
        (resultone === 2 && resultfour === 2) ||
        (resultone === 2 && resultfive === 2) ||
        (resultone === 2 && resultsix === 2) ||
        (resulttwo === 2 && resultthree === 2) ||
        (resulttwo === 2 && resultfour === 2) ||
        (resulttwo === 2 && resultfive === 2) ||
        (resulttwo === 2 && resultsix === 2) ||
        (resultthree === 2 && resultfour === 2) ||
        (resultthree === 2 && resultfive === 2) ||
        (resultthree === 2 && resultsix === 2) ||
        (resultfour === 2 && resultfive === 2) ||
        (resultfour === 2 && resultsix === 2) ||
        (resultfive === 2 && resultsix === 2)
      ) {
        played(userId);
        delete1Item(order, res);
      } else {
        res.json("Désolé, vous avez perdu.");
      }
    }
  );
}

function played(userId) {
  ClientModel.findOneAndUpdate(
    { _id: userId },
    {
      $set: {
        played: true,
      },
    },
    { new: true },
    (err, obj) => {
      if (err) {
        console.log("ERREUR --> ", err);
        return "update client err";
      } else {
        console.log("UPDATE PROFIL OK -- ", obj);
        return { played: true };
      }
    }
  );
}

function getNumber(order) {
  console.log("getnumbers -- ", order);
  return new Promise((resolve, reject) =>
    PatriesModel.find({ order: order }).then((data) => {
      console.log("DATA NUMBER", data);
      var result = data[0].number - 1;
      console.log(result);
      resolve(result);
    })
  );
}

function delete1Item(order, res) {
  Promise.all([getNumber(order)]).then((response) => {
    console.log("AFTER THEN -- ", response);
    var currentNumber = response[0];
    console.log("dete1item order -- ", order);
    console.log(currentNumber);
    PatriesModel.findOneAndUpdate(
      { order: order },
      {
        $set: {
          number: currentNumber,
        },
      },
      { new: true },
      (err, obj) => {
        if (err) {
          console.log("ERREUR --> ", err);
          return "deleteitem err";
        } else {
          console.log("UPDATE PATRIE OK -- ", obj);
          var patrie = obj.name;
          res.json(patrie);
        }
      }
    );
  });
}

function deleteMultiItem(order) {
  return new Promise((resolve, reject) =>
    Promise.all([getNumber(order)]).then((response) => {
      console.log("AFTER THEN -- ", response);
      var currentNumber = response[0];
      console.log("dete1item order -- ", order);
      console.log(currentNumber);

      PatriesModel.findOneAndUpdate(
        { order: order },
        {
          $set: {
            number: currentNumber,
          },
        },
        { new: true },
        (err, obj) => {
          if (err) {
            console.log("ERREUR --> ", err);
            return "deleteitem err";
          } else {
            console.log("UPDATE PATRIE OK -- ", obj);
            var patrie = obj.name;
            console.log("FINAL OBJ -- ", patrie);
            return resolve({ result: patrie });
          }
        }
      );
    })
  );
}

function delete2Item(order1, order2, res) {
  Promise.all([deleteMultiItem(order1), deleteMultiItem(order2)]).then(
    (response) => {
      var final = response[0].result + " & " + response[1].result;
      res.json(final);
    }
  );
}

function delete3Item(order1, order2, order3, res) {
  Promise.all([
    deleteMultiItem(order1),
    deleteMultiItem(order2),
    deleteMultiItem(order3),
  ]).then((response) => {
    var final =
      response[0].result +
      " & " +
      response[1].result +
      " & " +
      response[2].result;
    res.json(final);
  });
}

function checkStock(req, res) {
  var result = 0;
  PatriesModel.find().then((data) => {
    //console.log("DATA -- ", data);
    for (var i = 0; i <= data.length - 1; i++) {
      console.log(data[i].number);
      result = result + data[i].number;
    }
    res.json(result);
  });
  //res.json(PatriesModel.distinct("number").then((data) => console.log(data.obj)));
}

module.exports = router;

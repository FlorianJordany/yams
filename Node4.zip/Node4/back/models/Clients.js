const mongoose = require("mongoose");

const clientSchema = new mongoose.Schema({
  firstname: { type: String },
  lastname: { type: String },
  email: { type: String, unique: true },
  password: { type: String },
  played: false,
});

module.exports = mongoose.model("Client", clientSchema, "clients");

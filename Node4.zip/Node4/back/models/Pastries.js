const mongoose = require("mongoose");

const patriesSchema = new mongoose.Schema({
  name: { type: String },
  number: { type: Number },
  order: { type: Number },
});

module.exports = mongoose.model("Patries", patriesSchema, "patries");

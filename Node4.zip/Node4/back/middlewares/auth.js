const jsonwebtoken = require("jsonwebtoken");

module.exports = function auth(req, res, next) {
  if (!req.headers.authorization)
    return res
      .status(403)
      .send({ error: "Access denied! You must be authentified!" });

  // Extraction du token du header HTTP "Authorization"
  const [, token] = req.headers.authorization.split(" ");

  // Vérification de la validité du token
  try {
    const decodedToken = jsonwebtoken.verify(
      token,
      process.env.APP_TOKEN_SECRET
    );
    req.token = token;
    req.user = decodedToken;
    next();
  } catch (e) {
    return res.status(403).send({ error: "Access denied! Invalid token!" });
  }
};

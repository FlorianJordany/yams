import axios from "axios";

const yamsService = axios.create({
  baseURL: "http://localhost:7001",
  headers: {
    "Content-Type": "application/json",
  },
});

yamsService.interceptors.request.use((config) => {
  const token = window.localStorage.getItem("loginToken");
  config.headers.Authorization = `Bearer ${token}`;
  return config;
});

const APIService = {
  postLogin(email, password) {
    return yamsService
      .post(`/login`, { email, password })
      .then((res) => res.data);
  },

  postAddClient(firstname, lastname, email, password) {
    return yamsService
      .post(`/addClient`, { firstname, lastname, email, password })
      .then((res) => res.data);
  },

  getResult(userId, numbers) {
    return yamsService
      .post(`/play`, { userId, numbers })
      .then((res) => res.data);
  },

  checkStock() {
    return yamsService.get(`/stock`).then((res) => {
      if (res.data <= 30) {
        return false;
      } else {
        return true;
      }
    });
  },
};

export default APIService;

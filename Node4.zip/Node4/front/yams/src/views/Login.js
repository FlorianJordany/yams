import React, { useState } from "react";
import APIService from "../services/APIService";

export default function Login() {
  const [loginData, setLoginData] = useState({});

  function onInput(event) {
    setLoginData((prevState) => {
      prevState[event.target.name] = event.target.value;
      return { ...prevState };
    });
  }

  async function login(event) {
    event.preventDefault();
    const data = await APIService.postLogin(
      loginData.email,
      loginData.password
    );
    window.localStorage.setItem("loginToken", data.token);
    window.localStorage.setItem("userid", data.user._id);
    window.localStorage.setItem("played", data.user.played);
  }

  return (
    <form onSubmit={login}>
      <pre>{JSON.stringify(loginData, null, 2)}</pre>
      <input type="email" name="email" onInput={onInput} />
      <input type="password" name="password" onInput={onInput} />
      <button type="submit">Connexion</button>
    </form>
  );
}

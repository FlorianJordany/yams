import React, { useState, useEffect } from "react";
import APIService from "../services/APIService";

export default function Home() {
  const [yams, setYams] = useState([]);
  const [patries, setPatries] = useState();
  const userId = localStorage.getItem("userid");
  const played = localStorage.getItem("played");
  console.log(played);

  function playYams() {
    var yams = [];
    var pushYams = new Promise((resolve, reject) => {
      for (var i = 0; i < 5; i++) {
        yams.push(Math.floor(Math.random() * (6 - 1 + 1) + 1));
      }
      resolve(yams);
    });
    if (played === "true") {
      alert("Désolé vous avez déjà participer, vous ne pouvez plus jouer.");
    } else if (played === null || played === undefined) {
      alert("Vous devez être connecté pour jouer.");
    } else {
      Promise.all([checkStock()]).then((response) => {
        console.log("response2 ", response);
        if (response[0] === true) {
          pushYams.then((data) => setYams(data), getResult(yams));
        } else {
          alert(
            "Désole, toutes les patisseries ont été gagné, il n'est plus possible de joué."
          );
        }
      });
    }
  }

  function checkStock() {
    return new Promise((resolve, reject) => {
      APIService.checkStock().then((response) => {
        console.log("response ", response);
        if (response === true) {
          return resolve(true);
        } else {
          return resolve(false);
        }
      });
    });
  }

  function getResult(numbers) {
    APIService.getResult(userId, numbers).then((response) => {
      console.log(response);
      setPatries(response);
    });
  }

  return (
    <div>
      <h1>A vous de jouer :</h1>
      <p>Voici vos dés: {yams}</p>
      <button onClick={playYams}>Jouer</button>
      <p>Vous avez gagner : {patries}</p>
    </div>
  );
}

import React, { useState } from "react";
import APIService from "../services/APIService";

export default function Subscribe() {
  const [loginData, setLoginData] = useState({});

  function onInput(event) {
    setLoginData((prevState) => {
      prevState[event.target.name] = event.target.value;
      return { ...prevState };
    });
  }

  async function login(event) {
    event.preventDefault();
    const { token } = await APIService.postAddClient(
      loginData.firstname,
      loginData.lastname,
      loginData.email,
      loginData.password
    );
    window.localStorage.setItem("loginToken", token);
  }

  return (
    <form onSubmit={login}>
      <pre>{JSON.stringify(loginData, null, 2)}</pre>
      <input type="firstname" name="firstname" onInput={onInput} />
      <input type="lastname" name="lastname" onInput={onInput} />
      <input type="email" name="email" onInput={onInput} />
      <input type="password" name="password" onInput={onInput} />
      <button type="submit">Subscribe</button>
    </form>
  );
}

import React from "react";
import { Link } from "react-router-dom";

export default function Header() {
  function disconnect() {
    window.localStorage.removeItem("loginToken");
  }

  return (
    <nav>
      <div className="container">
        <ul>
          <li>
            <Link to="/">Homepage</Link>
          </li>
          <li>
            <Link to="/list">Results</Link>
          </li>
          <li>
            <Link to="/subscribe">Inscription</Link>
          </li>
          <li>
            <Link to="/login">Connexion</Link>
          </li>
          <li>
            <button onClick={disconnect}>Disconnect</button>
          </li>
        </ul>
      </div>
    </nav>
  );
}
